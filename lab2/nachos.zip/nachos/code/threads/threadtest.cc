#include "kernel.h"
#include "main.h"
#include "thread.h"
#include "stack.h"
#include "debug.h"
#include "assert.h"
void
SimpleThread(int which)
{
    int num;
    
    for (num = 0; num < 5; num++) {
        printf("*** thread %d looped %d times\n", which, num);
        kernel->currentThread->Yield();
    }


	Stack *s = new Stack(5);
	s->Push(1);
	s->Push(2);
	s->Push(3);
	s->Push(4);
	s->Push(5);
	s->display();
	s->Push(6);
	s->display();
	s->Pop();
	s->Pop();
	s->Pop();
	s->Pop();
	s->Pop();
	s->display();
	s->Pop();
	s->display();
}


void
ThreadTest()
{
    Thread *t = new Thread("forked thread");
    t->Fork((VoidFunctionPtr) SimpleThread, (void *) 1);
    
    SimpleThread(0);
}
