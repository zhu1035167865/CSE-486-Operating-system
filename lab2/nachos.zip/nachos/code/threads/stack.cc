#include<cstdlib>
#include<iostream>
#include "debug.h"
#include "stack.h"
#include "assert.h"
Stack::Stack(int sz){
	size=sz;
	top=0;
	EmptyStack=-1;
	stack = new int[size];
	}
	
	Stack::~Stack(){
		delete stack;
	}


	bool Stack::Full(){

	return(top==size);
}

	void Stack::Push(int value){
		if (!Full()){
		stack[top++]=value;}
		
		
}
	int Stack::Pop(){
		if(empty()){
			return 0;
		}
		else{
		int temp;
		temp = stack[top];
		--top;
		return temp;
	}
}
	bool Stack::empty(){
		return (top == EmptyStack);
}

	void Stack::display(){
		int i;
		cout <<"Stack is : " ;
		for(i=top-1;i>=0;i--)
			cout << stack[i] << endl;
		cout <<endl;

}
