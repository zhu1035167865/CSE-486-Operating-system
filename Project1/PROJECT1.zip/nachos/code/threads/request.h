
class Request{
private:
 char element;
 int request_id;
public:
//Request(char u[100], int rqtid, int rqtrid);
int getter_id();
char  getter_ele();
void setter(int id, char c);
Request();
};
