#include "kernel.h"
#include "main.h"
#include "thread.h"
#include "request.h"
#include "list.h"
const char* filenames[] = {"mickey_small.txt", "donald.txt"};

void print(Request *item_ptr){
char c;
c = item_ptr->getter_ele();
printf("%c",c);
}

void Project3Thread(int which)
{
   FILE * fp = fopen(filenames[which],"r");
  if (fp== NULL)
{
	printf("fail to open");
	exit(0);
}
Request *last_obj = new Request();
char c;
int id=0;
  List<Request*> *rlist = new List<Request*>();// a list where the request will end up in 
  while((c = fgetc(fp)) != EOF)
{
	Request *obj=  new Request();
	obj->setter(id,c);
	rlist->Append(obj);
	id++;
}
rlist->Apply(print);
int last_id = last_obj->getter_id();
printf("%d",last_id);
}
	
void ThreadTest()
{
   Thread *t = new Thread("forked thread");
   t->Fork((VoidFunctionPtr) Project3Thread, (void *) 0);
   Thread *x = new Thread("xx");
   x->Fork((VoidFunctionPtr) Project3Thread, (void *) 1);
}
