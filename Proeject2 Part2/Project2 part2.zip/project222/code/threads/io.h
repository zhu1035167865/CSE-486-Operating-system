// io.h
//  For details of the classes, see the descriptions of Project 1, available on
//  Blackboard.
#ifndef IO_ROUTINES_H
#define IO_ROUTINES_H

#include "list.h"
#include "thread.h"
#include <unistd.h>
#include <sys/wait.h>

#define KERNEL_BUF_SZ 4096

enum Operation {PRINT, READ};

class IO;
struct IOQueueItem;

class IORoutines {
public:
  IORoutines(IO* io_interface);
  void Print(const char* message); // simulated print system call
  void ReadFromFile(char *infile, char *buffer); // simulate file read call
  void IOInterruptHandler(IOQueueItem* done); // handles IO interrupts
  void Receive(char* url);
private:
  IO* io;
};

struct IOQueueItem {
  Operation operation; // type of operation
  Thread* thread; // pointer to the thread that issued this IO request
  char kernel_buffer[KERNEL_BUF_SZ]; // buffer managed by kernel
  char* user_buffer; // buffer managed by user program
  int message_index; // index of the message to read
  char* infile;        // file to read (no file output to be implemented at this time)
  int done_time; // for simulation purpose
};

class IO {
public:
  IO();
  ~IO();
  void SimulateIO(); // for simulation purpose
  void SetIORoutines(IORoutines* routines); // for simulation purpose
  void AddToIOQueue(IOQueueItem* item); // adds an item to internal IO queue
private:
  void RaiseIOInterrupt(IOQueueItem* item);
  SortedList<IOQueueItem*> io_queue;
  IORoutines* io_routines;
};

#endif
