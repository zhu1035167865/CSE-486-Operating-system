// io.cc
//  Please add implementation of IORoutines class in this file.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "io.h"
#include "main.h"

IORoutines::IORoutines(IO* io_interface) {
  io = io_interface;
}

// You implemented IORoutines::Print in Part 1.
void
IORoutines::Print(const char* message) {
    //Your implementation from Part 1
  IOQueueItem* IOProcess = new IOQueueItem;
  strcpy(IOProcess->kernel_buffer, message);
  IOProcess->operation= PRINT;
  IOProcess->thread= kernel->currentThread;
  io->AddToIOQueue(IOProcess);
  IntStatus newStatus= IntOff;
  IntStatus oldStatus= kernel->interrupt->SetLevel(newStatus);
  kernel->currentThread->Sleep(false);
  newStatus= kernel->interrupt->SetLevel(oldStatus);
}

// Please, implement IORoutines::ReadFromFile for Part 2 below
void
IORoutines::ReadFromFile(char* file_to_read, char* buffer) {
    //Your implementation for Part 2
  IOQueueItem* IOProcess = new IOQueueItem;
  IOProcess->operation= READ;
  IOProcess->thread= kernel->currentThread;
  IOProcess->user_buffer= buffer;
  IOProcess->infile = file_to_read;
  IntStatus newStatus= IntOff;
  IntStatus oldStatus= kernel->interrupt->SetLevel(newStatus);
  io->AddToIOQueue(IOProcess);
  kernel->currentThread->Sleep(false);
  strcpy(buffer, IOProcess->kernel_buffer);
  newStatus= kernel->interrupt->SetLevel(oldStatus);
}

void
IORoutines::IOInterruptHandler(IOQueueItem* done) {
    //Your implementation from Part 1
  switch(done->operation) {
    case PRINT:
	kernel->scheduler->ReadyToRun(done->thread);
      break;
    case READ:
	kernel->scheduler->ReadyToRun(done->thread);
      break;
    default:
      break;
  }
}

// IORoutines::ReadFromFile has already been implemented for you below.
void
IORoutines::Receive(char* url) {
    pid_t pid = fork();
    if (pid == 0) {
        char *argv[] = {"/usr/bin/wget", "-q", "-p", "-k", url, NULL };
        execv(argv[0], argv);
    }
    else {
        wait(NULL);
    }
}


static int Compare(IOQueueItem* a, IOQueueItem* b) {
  return a->done_time - b->done_time;
}

IO::IO(): io_queue(Compare) {
  srand(time(NULL));
  io_routines = NULL;
}

void
IO::SimulateIO() {
FILE *fp;
  
  while (!io_queue.IsEmpty() 
    && io_queue.Front()->done_time <= kernel->stats->totalTicks) {
    IOQueueItem* ready = io_queue.RemoveFront();
    switch (ready->operation) {
      case PRINT:
        printf("[%d]%s", kernel->stats->totalTicks, ready->kernel_buffer);
        break;
      case READ:
	  fp = fopen(ready->infile, "r");
//	  printf("\nreading from %s\n", ready->infile);
	  fgets(ready->kernel_buffer, 100, fp);
//	  printf("\nKernel Buffer Read %s\n", ready->kernel_buffer);
	  fclose(fp);
        break;
      default:
        break;
    }
    RaiseIOInterrupt(ready);
  }
}

void
IO::SetIORoutines(IORoutines* routines) {
   io_routines = routines; 
}

void
IO::AddToIOQueue(IOQueueItem* item) {
  item->done_time = kernel->stats->totalTicks + rand() % 10000;
  io_queue.Insert(item);
}

void
IO::RaiseIOInterrupt(IOQueueItem* item) {
  if (io_routines == NULL)
    return;
  io_routines->IOInterruptHandler(item);
}
