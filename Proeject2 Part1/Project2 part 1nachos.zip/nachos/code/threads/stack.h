#include"debug.h"
#include<cstdlib>
#include<iostream>

class Stack{
	public:
	Stack(int sz);
	~Stack();
	void Push(int value);
	bool Full();
	int  Pop();
	bool empty();
	void display();
	private:
	int size;
	int top;
	int *stack;
	int EmptyStack;
};
