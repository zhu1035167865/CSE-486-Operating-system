#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "io.h"
#include "main.h"

IORoutines::IORoutines(IO* io_interface) {
  io = io_interface;
}

// Please implement this. 
// You need to create a new IOQueueItem object
// initialize each field of the object properly
// insert the item to the IO queue
// put the current thread (i.e., the thread that called Print()) to sleep.
// make sure you turn off and turn the interrup back on whenever you perfom
// a que operation.
// Read existing Nachos code to get hint on syntax for all the code 
// you need to write.
void
IORoutines::Print(const char* message) {
 IOQueueItem* IOProcess = new IOQueueItem;
  strcpy(IOProcess->kernel_buffer, message);
  IOProcess->operation= PRINT;
  IOProcess->thread= kernel->currentThread;
  io->AddToIOQueue(IOProcess);
  IntStatus newStatus= IntOff;
  IntStatus oldStatus= kernel->interrupt->SetLevel(newStatus);
  kernel->currentThread->Sleep(false);
  newStatus= kernel->interrupt->SetLevel(oldStatus); 
}

// Please implement this
// This is the interrupt handler that is automatically called when 
// an I/O is complete. You need to take the waiting thread out of the
// I/O queue and insert it to the ready queue.
// Read the existing code to get hint and help on syntax.
void
IORoutines::IOInterruptHandler(IOQueueItem* done) {
    switch(done->operation) {
    case PRINT:
	kernel->scheduler->ReadyToRun(done->thread);
      break;
    default:
      break;
  }
}

static int Compare(IOQueueItem* a, IOQueueItem* b) {
  return a->done_time - b->done_time;
}

IO::IO(): io_queue(Compare) {
  srand(time(NULL));
  io_routines = NULL;
}

void
IO::SimulateIO() {
  while (!io_queue.IsEmpty() 
    && io_queue.Front()->done_time <= kernel->stats->totalTicks) {
    IOQueueItem* ready = io_queue.RemoveFront();
    printf("[%d]%s", kernel->stats->totalTicks, ready->kernel_buffer);
    RaiseIOInterrupt(ready);
  }
}

void
IO::SetIORoutines(IORoutines* routines) {
   io_routines = routines; 
}

void
IO::AddToIOQueue(IOQueueItem* item) {
  item->done_time = kernel->stats->totalTicks + rand() % 10000;
  io_queue.Insert(item);
}

void
IO::RaiseIOInterrupt(IOQueueItem* item) {
  if (io_routines == NULL)
    return;
  io_routines->IOInterruptHandler(item);
}
