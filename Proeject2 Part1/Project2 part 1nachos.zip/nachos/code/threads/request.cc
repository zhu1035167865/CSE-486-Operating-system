#include "request.h"

Request::Request()
{
 
}

void Request::setter(int id, char c){
request_id=id;
element=c;

}

char Request::getter_ele(){
return element;
}

int Request::getter_id(){
return request_id;
}
